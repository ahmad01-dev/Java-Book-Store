package Models;

import java.util.Date;

public class Sales {

    private String string;

    private Date date;

    public Sales() {
    }

    public Sales(String string) {
        this.string = string;
        date = new Date();
    }

    public Date getDate() {
        return date;
    }

    public String getString() {
        return string;
    }

    @Override
    public String toString() {
        return "Sales{" + "string=" + string + ", date=" + date + '}';
    }

}
