package Models;

public class Book {

    private String name;

    private String language;

    private String category;

    private double price;

    private int quantity;

    public Book() {
    }

    public Book(String name, String language, String category, double price, int quantity) {
        this.name = name;
        this.language = language;
        this.category = category;
        if (price > 0) {
            this.price = price;
        }
        if (quantity > 0) {
            this.quantity = quantity;
        }
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPrice() {
        return price;
    }

    public String getCategory() {
        return category;
    }

    public String getLanguage() {
        return language;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Book{" + "Name: " + name + ", Language: " + language + ", Category: " + category + ", Price:  " + price + ", Quantity: " + quantity + '}';
    }

}
