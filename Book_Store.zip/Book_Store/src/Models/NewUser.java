package Models;

public class NewUser {

    private String username;

    private String password;

    private long phone;

    private Address address;

    public NewUser() {
    }

    public NewUser(String username, String password, long phone, Address address) {
        this.username = username;
        this.password = password;
        if (phone >= 01000000) {
            this.phone = phone;
        } else {
            this.phone = 01000000;
        }
        this.address = address;
    }

    public Address getAddress() {
        return address;
    }

    public long getPhone() {
        return phone;
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    @Override
    public String toString() {
        return "Username: " + username + "  Password: " + password + "  Phone: " + phone + "  " + address;
    }

}
