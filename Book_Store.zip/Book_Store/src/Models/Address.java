package Models;

public class Address {

    private String street;

    private String city;

    private String country;

    public Address() {
    }

    public Address(String street, String city, String country) {
        this.street = street;
        this.city = city;
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public String getStreet() {
        return street;
    }

    @Override
    public String toString() {
        return "Address{" + "Street: " + street + ", City: " + city + ", Country: " + country + '}';
    }

}
