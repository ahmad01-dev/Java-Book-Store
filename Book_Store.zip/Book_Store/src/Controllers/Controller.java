package Controllers;

import Models.*;
import java.io.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Controller {

    ArrayList userNames = new ArrayList();
    ArrayList passwords = new ArrayList();
    ArrayList books = new ArrayList();
    ArrayList booksNames = new ArrayList();
    ArrayList sales = new ArrayList();

    public void addUser(String username, String password, Long phone, String street, String city, String country) {
        NewUser n = new NewUser(username, password, phone, new Address(street, city, country));
        writeToFile("Usernames", n.getUsername());
        writeToFile("Passwords", n.getPassword());
        writeToFile("Users", n.toString());
    }

    public boolean checkUser(String username, String password) {
        boolean result = false;
        readFromFile("Usernames", userNames);
        readFromFile("Passwords", passwords);
        if (userNames.contains(username) && passwords.contains(password)) {
            result = true;
        }

        return result;
    }

    public boolean checkAdmin(String username, String password) {
        boolean result = false;
        if (username.equalsIgnoreCase("Admin") && password.equalsIgnoreCase("Admin")) {
            result = true;
        }
        return result;
    }

    public void addBook(String name, String language, String category, double price, int quantity) {
        Book b = new Book(name, language, category, price, quantity);
        writeToFile("Books", b.toString());
        writeToFile("Books Names", b.getName());
    }

    public String showBooks() {
        readFromFile("Books", books);
        String s = "";
        for (int i = 0; i < books.size(); i++) {
            s += books.get(i).toString() + "\n";
        }
        return s;
    }

    public String showSearchedBook(String name) {
        String s = "Book is not found!";
        readFromFile("Books Names", booksNames);
        for (int i = 0; i < booksNames.size(); i++) {
            if (booksNames.get(i).equals(name)) {
                s = books.get(i).toString();
                break;
            }
        }
        return s;
    }

    public void addToSales(String s) {
        Sales sl = new Sales(s);
        writeToFile("Sales", sl.toString());
    }

    public String showSales() {
        readFromFile("Sales", sales);
        String s = "";
        for (int i = 0; i < sales.size(); i++) {
            s += sales.get(i).toString() + "\n";
        }
        return s;
    }

    public void writeToFile(String fileName, String data) {
        try {
            FileWriter fw = new FileWriter(fileName.concat(".txt"), true);
            fw.write(data + "\n");
            fw.close();
        } catch (IOException ioe) {
        }
    }

    public void readFromFile(String fileName, ArrayList list) {
        try {
            FileInputStream fs = new FileInputStream(fileName.concat(".txt"));
            InputStreamReader ir = new InputStreamReader(fs);
            BufferedReader br = new BufferedReader(ir);
            while (br.ready()) {
                String line = "";
                line = br.readLine();
                list.add(line);
            }
        } catch (IOException ioe) {
        }
    }
}
