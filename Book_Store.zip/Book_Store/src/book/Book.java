package book;

import Views.loginForm;

public class Book {

    public static void main(String[] args) {
        loginForm l = new loginForm();
        l.setVisible(true);
    }

}
